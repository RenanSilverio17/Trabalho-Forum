import "./postagem.style.css"

export function Postagem({children}) {
    
    return (
        <section className="postagem">
            {children}
        </section>
    )

}