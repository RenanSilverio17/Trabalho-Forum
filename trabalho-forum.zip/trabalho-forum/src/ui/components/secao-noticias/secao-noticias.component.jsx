import "./secao-noticias.style.css"

export function SecaoNoticias() {
    return (
        <section className="noticias">
            NOTICIAS E TRENDS
        </section>
    )
}