import "./balao-direita.style.css"

export function BalaoDireita({mensagem}) {

    return (
        <div className="balao-direita">
            <p>{mensagem}</p>
        </div>
    )

}