import "./secao-postagens.style.css";
import { BalaoDireita } from "../balao-direita/balao-direita.component";
import { BalaoEsquerda } from "../balao-esquerda/balao-esquerda.component";
import { BolaColorida } from "../bola-colorida/bola-colorida.component";
import { Postagem } from "../postagem/postagem.component";

export function SecaoPostagens() {
  return (
    <section className="postagens">
      <header>
        <BolaColorida cor={"vermelho"} />
        No que você está pensando?
        <button>Enviar</button>
      </header>
      <Postagem>
        <BolaColorida cor={"rosa"} />
        <BalaoEsquerda mensagem={"Olá"} />
      </Postagem>

      <Postagem>
        <BalaoDireita mensagem={""} />
        <BolaColorida cor={"vermelho"} />
      </Postagem>

      <Postagem>
        <BolaColorida cor={"amarelo"} />
        <BalaoEsquerda mensagem={""} />
      </Postagem>

      <Postagem>
        <BolaColorida cor={"verde"} />
        <BalaoEsquerda mensagem={""} />
      </Postagem>
    </section>
  );
}
