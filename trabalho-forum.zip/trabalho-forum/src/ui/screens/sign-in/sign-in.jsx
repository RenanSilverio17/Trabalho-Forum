import { Link } from "react-router-dom";
import { imgLogo } from "../../../assets";

import "./sign-in.css";

function SignIn() {
  return (
    <div className="background-blue">
      <div className="sign-Quadrado">
        <div className="sign-container">
          <header className="sign-header">
            <img src={imgLogo} alt="minhalogo" className="sign-logo" />
            <span>Bem vindo de volta</span>
          </header>

          <form>
            <div className="sign-inputContainer">
              <label htmlFor="Email">E-mail</label>
              <input
                type="text"
                name="email"
                id="email"
                placeholder="02267074079@gmail.com"
              />
            </div>

            <div className="sign-inputContainer">
              <label htmlFor="senha">Senha</label>
              <input
                type="senha"
                name="senha"
                id="senha"
                placeholder="********"
              />
            </div>

            <Link to="/">Não tenho conta</Link>

            <Link to="/feed" className="sign-button">
              Entrar
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}

export default SignIn;
