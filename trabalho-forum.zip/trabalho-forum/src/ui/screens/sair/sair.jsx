import { Link } from "react-router-dom";
import semFoto from "../../../assets/SemFoto.png";

import "./sair.css";

export function Sair() {
  return (
    <>
      <div className="sair-container">
        <div className="sair-sidebar">
          <div className="sair-title">
            Mundo Novo
            <img src={semFoto} alt="image" className="sair-image" />
          </div>
          <div className="sair-options">
            <ul>
              <li> Feed</li>
              <li>Perfil</li>
              <li>Buscar</li>
              <li>Notificações</li>
              <li>Sair</li>
            </ul>
          </div>
          <button className="sair-button">Sair</button>
        </div>
        <div className="sair-main-content">
          <div className="sair-content">
            <div className="sair-inside">
              <img src={semFoto} alt="icone" className="sair-icon" />
              <p>@eduardaramos___</p>
              <p> Deseja sair mesmo?</p>
              <div className="sair-gap">
                <Link to="/sign-in" className="sair-buttons">
                  Sair
                </Link>
              </div>
              <Link to="/feed" className="sair-buttons">
                Cancelar
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
