import imgBemVindo from "./bem-vindo.png";
import imgCriarConta from "./criar-conta.png";
import imgLogo from "./logo.png";

export { imgBemVindo, imgCriarConta, imgLogo };
